% konkat(L1,L2,L3)
% spe�niony, gdy L3 jest polaczeniem list L1 i L2
% ----------------------------------------------

% rekurencja ze wzgledu na liste L1:

% warunek ko�cz�ce rekurencj�: polaczenie listy
% pustej z lista L daje lsite L
	konkat([],L,L).

% rekurencja:
% g�owa listy L3 jest glowa lsity L1
% ogon listy L3 jest polaczeniem ogona listy L1
% z lista L2
	konkat([H1|T1],L2,[H1|T3]):-konkat(T1,L2,T3).


% ------------------------------------------


% odwrotna_lista(L1, L2) - spe�niony, gdy lista L2 jest 
% odwr�ceniem % listy L1
% warunek konczacy rekurencje

odwrotna_lista([],[]).

% rekurencja

odwrotna_lista([H|T1],L):-odwrotna_lista(T1,T2),konkat(T,[H],L).

