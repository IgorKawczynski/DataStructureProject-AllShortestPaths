% wywolanie predykatow dla kazdego elem listy

% predykaty :

% --dodatni(X), spe�niony gdy X jest liczba dodatnia

	dodatni(X):-X>0.

% --lista_daodatnia(L), spe�niony gdy wszystkie elem. listy sa > 0

	lista_dodatnia(L):-maplist(dodatni,L).

% --wiekszy_od(X,Y), spelniony gdy Y jest wieksze od X

	wiekszy_od(X,Y):-Y>X.




/*
lista_dodatnia([1,2,3]). - czy lista z elem 1,2,3 ma wszystkie el dodatnie








*/


kwadrat(X,Y):-Y is X**2.

kwadrat_listy(L1,L2):-
     maplist(kwadrat,L1,L2).


% wiekszy_od(X,Y).
% spe�niony, gdy Y jest wi�ksze od X

% wiekszy_od(X,Y):-Y<X.

% wiekszy_od_lista(+X,+L).
% spe�niony, gdy wszystkie elementy listy �
% s� wi�ksze od X


% ---------------------------------

wiekszy_od(X,Y):- Y>X.

wiekszy_od_lista(X,L):-
      maplist(wiekszy_od(X),L).

wieksza_lista(L1,L2):-
      maplist(wiekszy_od,L2,L1).

% ---------------------------------
mniejszy_o2(X,Y):-Y is X-2.

lista_mniejsza_o2(L1,L2):-maplist(mniejszy_o2,L1,L2).

% ponizej rekurencyjnie
lista_mniejsza_o2_2([],[]).
lista_mniejsza_o2_2([X|T1],[Y|T2]):-
         Y is X-2, lista_mniejsza_o2_2(T1,T2).


/* 
lista_mniejsza_o2([4,2],[2,0]).
*/

