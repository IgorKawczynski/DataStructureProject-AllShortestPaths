liczba_elem([],0).
liczba_elem([X|T],N):-
     liczba_elem(T,K), N is K+1 .




/*
liczba_elem([1,2],2).
liczba_elem([],N).
liczba([1,2,3,4],X).


*/