% lista_wieksza_o2(L1,L2)-SPE�NIONY, GDY ELEMENTY LISTY
% L2 S� ODPOWIEDNIMI ELEMENTAMI LISTY L1 POWI�KSZONYMI O 2



lista_wieksza_o2([],[]).
lista_wieksza_o2([L1|T1],[L2|T2]):-
L2 is L1+2,
lista_wieksza_o2(T1,T2).


/*
lista_wieksza_o2([1,3],[3,5]).
lista_wieksza_o2([2,4,5],X).

*/