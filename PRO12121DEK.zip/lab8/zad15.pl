lista_wieksza_o2([],[]).
lista_wieksza_o2([X|T1],[Y|T2]):-
         Y is X+2, lista_wieksza_o2(T1,T2).



/*
lista_wieksza_o2([1,3],[3,5]).
lista_wieksza_o2([2,4,5],X).

*/