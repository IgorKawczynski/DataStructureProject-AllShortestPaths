%kwadrat_listy(+L1,?L2).
%spe�niony, gdy elementy listy L2 jest list� liczbow�
%element�w listy L1; lista L1 jest list� liczbow�
%ograniczenie: L1 i L2 s� listami liczbowymi
-------------------------------------------------------

%warunek ko�cz�cy rekurencj�: kwadrat listy pustej
%jest lista pust�.

kwadrat_listy([],[]).

%rekurencja

kwadrat_listy([H1|T1],[H2|T2]):-
              H2 is H1*H1,
	      kwadrat_listy(T1,T2).



/*
uzgodnienie list
[X|T]  [a,f(b),c,d]
X=a, T=[f(b),c,d]
[a,b] [X,Y|T]
X=a,Y=b,T=[]
[b] [X,Y|T]
Te listy nie dadz� si� uzgodni�, bo pierwsza lista posiada zbyt ma�o element�w.

1.[a,[b,a]] [X|T]
X=a T=[[b,c]]

2.[X,Y|T] [a,[b,c]]
X=a, Y=[b,c], T=[]

?- kwadrat_listy([2,4],[4,16]).
?- kwadrat_listy([1,2],[1,4]).
?- kwadrat_listy([2,4],X).
?- kwadrat_liczby(X,[4,25]).

co jest kwadratem listy pustej ?
?- kwadrat_listy([], X).
*/