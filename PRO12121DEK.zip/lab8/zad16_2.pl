% liczba_elem(L,N)-SPE�NIONY,GDY N JEST LICZBA ELEMENTOW LISTY L

liczba_elem([],0).
liczba_elem([L|T],N1):-liczba_elem(T,N2), N1 is N2+1.

/*
?- liczba_elem([1,5], 3).
?- liczba_elem([],N).
*/